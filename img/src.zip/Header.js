import React from "react";
import "./App.css";
const Header =() =>{
return(
     <div className="box1">제품정보</div>
     
    )
}
export default Header;