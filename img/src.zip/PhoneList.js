import React from 'react';

function Phone({ phone }) {
   return (
         <div className='App'>
            
              <div className='pbox'>
                <h2>{phone.pname}</h2>
               <img src={phone.pimg} alt={phone.pname} />
               <p>{phone.ptext}</p>
             </div>
        
         </div>
   );
}
 
function PhoneList() {
 
   const phones = [
      {
         id: 1,
         pname: '삼성S23',
         pimg: require('./img/pic1.jpg'),
         ptext:'삼성 2023최신폰 lorem text....'
      },
      {
         id: 2,
         pname: '삼성S24 pro',
         pimg: require('./img/pic2.jpg'),
         ptext:'lorem text....'
      },
      {
         id: 3,
         pname: 'iphone 13',
         pimg: require('./img/pic3.jpg'),
         ptext:'lorem text....'
      },
    {
         id: 4,
         pname: 'iphone 15',
         pimg: require('./img/pic4.jpg'),
         ptext:'lorem text....'

      },
 {
         id: 5,
         pname: 'iphone 16 pro',
         pimg: require('./img/pic5.jpg'),
         ptext:'lorem text....'
      },
{
         id: 6,
         pname: 'iphone 16',
         pimg: require('./img/pic6.jpg'),
         ptext:'lorem text....'
      },
{
         id: 7,
         pname: 'iphone 15',
         pimg: require('./img/pic7.jpg'),
         ptext:'lorem text....'
      },
{
         id: 8,
         pname: 'iphone 13 pro',
         pimg: require('./img/pic8.jpg'),
         ptext:'lorem text....'
      }
   ];
 
   return (
      <div>
         {
            phones.map((phone,index) => (<Phone phone={phone} key={index} />)) 
         }
      </div>
   )
}
 
export default PhoneList;