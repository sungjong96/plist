import React from "react";
import "./App.css";
const Footer =() =>{
return(
     <div className="f_box1">copyright 2024 react.com</div>
)
}
export default Footer;